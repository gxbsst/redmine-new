require File.dirname(__FILE__) + '/../../../../app/helpers/issues_helper'

module AppNotificationsHelper
  include IssuesHelper
end
