# Load the Redmine helper
require File.expand_path(File.dirname(__FILE__) + '/../../../test/test_helper')

class Test::Unit::TestCase
  include FactoryGirl::Syntax::Methods
end
