module CorpWechatsHelper
    def a
    end
end
